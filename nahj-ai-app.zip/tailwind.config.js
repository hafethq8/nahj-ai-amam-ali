module.exports = {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        arabic: ['"Amiri"', 'serif'],
        persian: ['"Vazirmatn"', 'serif'],
        english: ['"Inter"', 'sans-serif']
      }
    }
  },
  plugins: []
}
